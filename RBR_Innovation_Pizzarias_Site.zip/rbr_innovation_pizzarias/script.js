const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
menuButton?.addEventListener('click', () => {
  const opened = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(opened));
});
document.querySelectorAll('.nav a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuButton?.setAttribute('aria-expanded', 'false');
}));
document.getElementById('year').textContent = new Date().getFullYear();

const phone = '558981879429';
document.querySelectorAll('[data-plan]').forEach(link => {
  link.addEventListener('click', () => {
    const plan = link.dataset.plan;
    const message = `Olá! Tenho interesse no plano ${plan} da RBR Innovation. Gostaria de saber mais detalhes.`;
    document.getElementById('whatsapp-link').href = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
  });
});
document.getElementById('whatsapp-link').addEventListener('click', function () {
  if (!this.href.includes('?text=')) {
    const message = 'Olá! Gostaria de solicitar um orçamento para um site profissional para minha pizzaria.';
    this.href = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
  }
});