# RBR Innovation — Landing page para pizzarias

Projeto estático responsivo, pronto para hospedagem na Netlify.

## Arquivos
- `index.html`: estrutura e conteúdo do site
- `styles.css`: identidade visual preta e dourada, responsividade
- `script.js`: menu mobile, ano automático e mensagens de WhatsApp
- `assets/`: imagens fornecidas para o projeto

## Publicar na Netlify
1. Extraia o ZIP no seu computador.
2. Acesse https://app.netlify.com/drop
3. Arraste a pasta `rbr_innovation_pizzarias` (ou a pasta extraída) para a área indicada.
4. Aguarde a publicação e copie o link gerado.

## Usar no Lovable
Envie os arquivos do projeto como referência e peça para o Lovable importar/recriar a landing page mantendo a identidade visual preta e dourada.

## Personalização importante
O WhatsApp está configurado para `+55 89 8187-9429` (número informado na conversa). Confirme se esse é o número comercial correto antes de divulgar.
Os preços exibidos são R$ 150, R$ 300 e R$ 500, conforme as artes enviadas. Revise escopo e condições comerciais antes de publicar.

Não há backend ou banco de dados: os botões de contato abrem uma conversa no WhatsApp.
